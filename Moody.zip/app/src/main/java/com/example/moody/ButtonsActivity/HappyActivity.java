package com.example.moody.ButtonsActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.moody.AdaptersPackage.AdapterHappy;
import com.example.moody.AdaptersPackage.CommonAdapter;
import com.example.moody.ModelsPackage.ModelHappy;
import com.example.moody.R;
import com.example.moody.RegisterActivity;
import com.example.moody.TitleDescriptionActivity;
import com.example.moody.TtileDescGetterSetter;
import com.example.moody.databinding.ActivityHappyBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class HappyActivity extends AppCompatActivity {

    ActivityHappyBinding binding;
    String userNameAndPass="sakshi";
    FirebaseDatabase database;
    public static String currentMood;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHappyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();
        database = FirebaseDatabase.getInstance();

       // ArrayList<ModelHappy>happyArrayList = new ArrayList<>();
        //AdapterHappy adapterHappy = new AdapterHappy(happyArrayList,this);
        ArrayList<TtileDescGetterSetter>List = new ArrayList<>();
        CommonAdapter commonAdapter=new CommonAdapter(List,this);



        database.getReference()
                .child("Data")
                .child(RegisterActivity.usernamePlusPass1)
                .child(RegisterActivity.usernamePlusPass1+"Happy")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot)
                    {
                        List.clear();
                       for(DataSnapshot ds: snapshot.getChildren())
                       {
                           TtileDescGetterSetter t=ds.getValue(TtileDescGetterSetter.class);
                           List.add(t);
                       }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error)
                    {

                    }
                });
        //this is to scroll the activity up and down
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        binding.recyclerViewHappy.setLayoutManager(linearLayoutManager);
        // binding.recyclerViewHappy.setAdapter(adapterHappy);
        binding.recyclerViewHappy.setAdapter(commonAdapter);


         binding.add.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v)
             {
                 Intent i = new Intent(HappyActivity.this, TitleDescriptionActivity.class);
                 i.putExtra("CurrentMood","Happy");
                 startActivity(i);

             }
         });

    }
}