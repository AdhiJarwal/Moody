package com.example.moody;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.example.moody.databinding.ActivityTitleDescriptionBinding;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.example.moody.RegisterActivity;

public class TitleDescriptionActivity extends AppCompatActivity
{

    ActivityTitleDescriptionBinding binding;
    String userNameAndPass="sakshi";
    DatabaseReference databasereference;
    TtileDescGetterSetter td;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTitleDescriptionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //to hide the action bar
        getSupportActionBar().hide();

        databasereference = FirebaseDatabase.getInstance().getReference().child("Data");



        binding.saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String title = binding.titleWriting.getText().toString();
                String des = binding.descriptionWriting.getText().toString();
                String mood=getIntent().getExtras().getString("CurrentMood");
                if(mood.equals("Happy"))
                {
                    userNameAndPass=RegisterActivity.usernamePlusPass1;
                    td = new TtileDescGetterSetter(title,des);
                    databasereference.child(userNameAndPass).child(userNameAndPass+"Happy").push().setValue(td);
                }
                if(mood.equals("Sad"))
                {
                    userNameAndPass=RegisterActivity.usernamePlusPass1;
                    td = new TtileDescGetterSetter(title,des);
                    databasereference.child(userNameAndPass).child(userNameAndPass+"Sad").push().setValue(td);
                }
                if(mood.equals("Angry"))
                {
                    userNameAndPass=RegisterActivity.usernamePlusPass1;
                    td = new TtileDescGetterSetter(title,des);
                    databasereference.child(userNameAndPass).child(userNameAndPass+"Anger").push().setValue(td);
                }
                if(mood.equals("Other"))
                {
                    userNameAndPass=RegisterActivity.usernamePlusPass1;
                    td = new TtileDescGetterSetter(title,des);
                    databasereference.child(userNameAndPass).child(userNameAndPass+"Other").push().setValue(td);
                }



            }
        });



    }
}