package com.example.moody.ModelsPackage;

public class ModelSad {

    private String msgTypeSad;

    public ModelSad() {
    }

    public ModelSad(String msgTypeSad) {
        this.msgTypeSad = msgTypeSad;
    }

    public String getMsgTypeSad() {
        return msgTypeSad;
    }

    public void setMsgTypeSad(String msgTypeSad) {
        this.msgTypeSad = msgTypeSad;
    }
}
