package com.example.moody.ModelsPackage;

public class ModelHappy
{
    private String msgTypeHappy;

    public ModelHappy() {
    }

    public ModelHappy(String msgTypeHappy) {
        this.msgTypeHappy = msgTypeHappy;
    }

    public String getMsgTypeHappy() {
        return msgTypeHappy;
    }

    public void setMsgTypeHappy(String msgTypeHappy) {
        this.msgTypeHappy = msgTypeHappy;
    }
}


