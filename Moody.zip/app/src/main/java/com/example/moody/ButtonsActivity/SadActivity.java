package com.example.moody.ButtonsActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.moody.AdaptersPackage.AdapterSad;
import com.example.moody.ModelsPackage.ModelSad;
import com.example.moody.TitleDescriptionActivity;
import com.example.moody.databinding.ActivitySadBinding;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class SadActivity extends AppCompatActivity {

    ActivitySadBinding binding;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySadBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        reference = FirebaseDatabase.getInstance().getReference();

        //reference.child("Users").child("Adhi1234").child("Username").setValue("Adhi");

        // this is to hide the actionbar
        getSupportActionBar().hide();


        binding.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SadActivity.this, TitleDescriptionActivity.class);
                i.putExtra("CurrentMood","Sad");
                startActivity(i);

            }
        });

    }
}