package com.example.moody;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import com.example.moody.ButtonsActivity.AngryActivity;
import com.example.moody.ButtonsActivity.HappyActivity;
import com.example.moody.ButtonsActivity.OtherActivity;
import com.example.moody.ButtonsActivity.SadActivity;
import com.example.moody.databinding.ActivitySelectMoodBinding;

public class SelectMoodActivity extends AppCompatActivity {

    ActivitySelectMoodBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySelectMoodBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        binding.happyMoodBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectMoodActivity.this, HappyActivity.class);
                startActivity(intent);

            }
        });

        binding.sadMoodBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectMoodActivity.this, SadActivity.class);
                startActivity(intent);

            }
        });

        binding.angryMoodBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(SelectMoodActivity.this, AngryActivity.class);
                startActivity(intent);

            }
        });

        binding.otherMoodBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SelectMoodActivity.this, OtherActivity.class);
                startActivity(intent);

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch ((item.getItemId()))
        {
            case (R.id.settings):
                break;

            case (R.id.logout):
                break;

        }
        return true;
    }
}