package com.example.moody.AdaptersPackage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.moody.ModelsPackage.ModelAngry;
import com.example.moody.R;
import com.example.moody.TtileDescGetterSetter;

import java.util.ArrayList;

public class CommonAdapter extends RecyclerView.Adapter<CommonAdapter.viewHolders>
{
    ArrayList<TtileDescGetterSetter> list;
    Context context;

    public CommonAdapter(ArrayList<TtileDescGetterSetter>list,Context context)
    {
        this.list=list;
        this.context=context;
    }
    @NonNull
    @Override
    public viewHolders onCreateViewHolder(@NonNull ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_to_display,parent,false);
        return new CommonAdapter.viewHolders(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolders holder, int position)
    {

        TtileDescGetterSetter ttileDescGetterSetter=list.get(position);
        holder.textView12.setText(ttileDescGetterSetter.getTitle());

    }

    @Override
    public int getItemCount()
    {
        return list.size();
    }

    public class viewHolders extends RecyclerView.ViewHolder
    {

        TextView textView12 ;
        public viewHolders(@NonNull View itemView)
        {
            super(itemView);
            textView12 = itemView.findViewById(R.id.textView12);
        }
    }
}
