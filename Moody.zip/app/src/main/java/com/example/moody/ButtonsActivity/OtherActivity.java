package com.example.moody.ButtonsActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.moody.AdaptersPackage.AdapterOther;
import com.example.moody.ModelsPackage.ModelOther;
import com.example.moody.R;
import com.example.moody.TitleDescriptionActivity;
import com.example.moody.databinding.ActivityOtherBinding;

import java.util.ArrayList;

public class OtherActivity extends AppCompatActivity {

    ActivityOtherBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOtherBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        ArrayList<ModelOther>OtherArrayList = new ArrayList<>();

        AdapterOther adapterOther = new AdapterOther(OtherArrayList,this);

        //this is to scroll the activity up and down
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        binding.recyclerViewOther.setLayoutManager(linearLayoutManager);
        binding.recyclerViewOther.setAdapter(adapterOther);

        binding.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(OtherActivity.this, TitleDescriptionActivity.class);
                i.putExtra("CurrentMood","Other");
                startActivity(i);

            }
        });

    }
}