package com.example.moody.ModelsPackage;

public class ModelAngry {

    private String msgTypeAngry;

    public ModelAngry() {
    }

    public ModelAngry(String msgTypeAngry) {
        this.msgTypeAngry = msgTypeAngry;
    }

    public String getMsgTypeAngry() {
        return msgTypeAngry;
    }

    public void setMsgTypeAngry(String msgTypeAngry) {
        this.msgTypeAngry = msgTypeAngry;
    }
}
