package com.example.moody.ButtonsActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.moody.AdaptersPackage.AdapterAngry;
import com.example.moody.ModelsPackage.ModelAngry;
import com.example.moody.R;
import com.example.moody.TitleDescriptionActivity;
import com.example.moody.databinding.ActivityAngryBinding;

import java.util.ArrayList;

public class AngryActivity extends AppCompatActivity {

    ActivityAngryBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAngryBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getSupportActionBar().hide();

        ArrayList<ModelAngry>AngryArrayList = new ArrayList<>();


        AdapterAngry adapterAngry = new AdapterAngry(AngryArrayList,this);

        //this is to scroll the activity up and down
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        binding.recyclerViewAngry.setLayoutManager(linearLayoutManager);
        binding.recyclerViewAngry.setAdapter(adapterAngry);

        binding.add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(AngryActivity.this, TitleDescriptionActivity.class);
                i.putExtra("CurrentMood","Angry");
                startActivity(i);

            }
        });

    }
}