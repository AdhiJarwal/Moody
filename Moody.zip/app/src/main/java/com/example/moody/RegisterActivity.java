package com.example.moody;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.moody.ButtonsActivity.HappyActivity;
import com.example.moody.databinding.ActivityRegisterBinding;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    ActivityRegisterBinding binding;
    DatabaseReference databasereference, databaseReference2;
    public String usernamePlusPass;
    public static String usernamePlusPass1;




    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        binding = ActivityRegisterBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        databasereference = FirebaseDatabase.getInstance().getReference().child("Users");
        databaseReference2 = FirebaseDatabase.getInstance().getReference().child("Data");

        //to hide the actionbar
        getSupportActionBar().hide();

        binding.registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                String regUser="",pass1="",pass2="";
                regUser = binding.usernameRegister.getText().toString();
                pass1 = binding.passwordRegister.getText().toString();
                pass2 = binding.confirmPasswordRegister.getText().toString();

                usernamePlusPass = regUser + pass1;
                usernamePlusPass1=usernamePlusPass;




               // registerActivity.usernamePlusPass = usernamePlusPass;

                if(pass1.equals(pass2) && !regUser.equals("") && !pass1.equals(""))
                {
                    // this will insert registration info(username and password) into firebase
                    regInfo obj = new regInfo(regUser, pass1);
                    databasereference.child(usernamePlusPass).setValue(obj);

                    //this will insert the data(mood data) into firebase

                    databaseReference2.child(usernamePlusPass).child(regUser+pass1+"happy");
                    databaseReference2.child(usernamePlusPass).child(regUser+pass1+"sad");
                    databaseReference2.child(usernamePlusPass).child(regUser+pass1+"angry");
                    databaseReference2.child(usernamePlusPass).child(regUser+pass1+"other");

                    Toast.makeText(RegisterActivity.this, "User registered succesfully", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(RegisterActivity.this, IntroductionPageActivity.class);
                    startActivity(intent);
                    RegisterActivity.this.finish();
                }

                else if(!pass1.equals(pass2))
                {
                    binding.confirmPasswordRegister.setError("Password does not matches");
                }
                else
                {
                    binding.usernameRegister.setError("Filed can not be empty");
                    binding.passwordRegister.setError("Filed can not be empty");
                    binding.confirmPasswordRegister.setError("Filed can not be empty");
                }

            }
        });

    }
}