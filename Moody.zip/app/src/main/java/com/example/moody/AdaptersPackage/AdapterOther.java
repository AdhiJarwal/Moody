package com.example.moody.AdaptersPackage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.moody.ModelsPackage.ModelOther;
import com.example.moody.R;

import java.util.ArrayList;

public class AdapterOther extends RecyclerView.Adapter<AdapterOther.viewHolders>
{

    ArrayList<ModelOther>list;
    Context context;


    public AdapterOther(ArrayList<ModelOther> list, Context context) {
        this.list = list;
        this.context = context;
    }

    @NonNull
    @Override
    public viewHolders onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_to_display,parent,false);
        return new viewHolders(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolders holder, int position)
    {
        ModelOther modelOther = list.get(position);

        holder.textView12.setText(modelOther.getMsgTypeOther());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class viewHolders extends RecyclerView.ViewHolder
    {

        TextView textView12 ;
        public viewHolders(@NonNull View itemView)
        {
            super(itemView);
            textView12 = itemView.findViewById(R.id.textView12);
        }
    }


}


