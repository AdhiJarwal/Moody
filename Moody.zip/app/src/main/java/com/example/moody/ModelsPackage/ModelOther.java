package com.example.moody.ModelsPackage;

public class ModelOther {

    private String msgTypeOther;

    public ModelOther() {
    }

    public ModelOther(String msgTypeOther) {
        this.msgTypeOther = msgTypeOther;
    }

    public String getMsgTypeOther() {
        return msgTypeOther;
    }

    public void setMsgTypeOther(String msgTypeOther) {
        this.msgTypeOther = msgTypeOther;
    }
}
